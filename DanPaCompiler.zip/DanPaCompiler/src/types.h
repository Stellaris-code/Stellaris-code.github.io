/*
types.h

Copyright (c) 25 Yann BOUCHER (yann)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
#ifndef TYPES_H
#define TYPES_H

typedef enum type_t
{
    INT,
    REAL,
    STR,
    VOID,

    TYPES_END
} type_t;
extern const char* types_str[TYPES_END];

typedef struct function_t function_t;
typedef struct program_t program_t;

extern function_t* type_current_function;
extern program_t*  type_current_program ;

typedef struct expression_t expression_t;
typedef struct primary_expression_t primary_expression_t;
type_t get_prim_expr_type(const primary_expression_t* prim_expr);
type_t get_expression_type(const expression_t* expr);
int can_implicit_cast(type_t lhs, type_t to);
int can_explicit_cast(type_t lhs, type_t to);

#endif // TYPES_H
