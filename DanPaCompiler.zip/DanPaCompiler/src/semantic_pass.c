/*
semantic_pass.c

Copyright (c) 26 Yann BOUCHER (yann)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#include "semantic_pass.h"

#include <string.h>
#include <stdio.h>
#include "error.h"

#define AST_PASS_NAME semanal
#include "ast_functions.h"

static int in_function;
static int nest_depth;
static function_t* current_function;
static program_t*  current_program ;

// FIXME : at the end of a compound statement, mark outlived variables as invalid
// wtf is this fixme ? to current day me, it seems okay
static local_variable_t* find_local(ident_t* ident, int* id)
{
    for (int i = 0; i < current_function->locals.size; ++i)
    {
        local_variable_t* item = &current_function->locals.ptr[i];
        if (item->nest_depth <= nest_depth && strcmp(item->ident.name->data.str, ident->name->data.str) == 0) // FIXME : wtf it won't work idiot
        {
            *id = i;
            return item;
        }
    }
    return NULL;
}

static global_variable_t* find_global(ident_t* ident, int* id)
{
    for (int i = 0; i < current_program->globals.size; ++i)
    {
        global_variable_t* item = &current_program->globals.ptr[i];
        if (strcmp(item->ident.name->data.str, ident->name->data.str) == 0)
        {
            *id = i;
            return item;
        }
    }
    return NULL;
}

static void generate_type_conversion(token_t* where, expression_t* in, type_t target)
{
    if (in->value_type != target)
    {
        if (!can_implicit_cast(in->value_type, target))
        {
            error(where->row, where->col, where->filename,
                  "cannot implicitly cast '%s' to '%s'\n", types_str[in->value_type], types_str[target]);
        }

        expression_t* new_expression = (expression_t*)danpa_alloc(sizeof(expression_t));
        *new_expression = *in; // copy current expression
        new_expression->value_type = target;

        // reuse 'in' to store the new cast expression
        in->kind = PRIM_EXPR;
        primary_expression_t* cast_prim_expr = &in->prim_expr;
        primary_expression_t* target_prim_exp = (primary_expression_t*)danpa_alloc(sizeof(primary_expression_t));
        cast_prim_expr->type = CAST_EXPRESSION;
        cast_prim_expr->cast_expr.target_type = target;
        cast_prim_expr->cast_expr.expr = target_prim_exp;

        target_prim_exp->type = ENCLOSED;
        target_prim_exp->expr = new_expression;
    }
}

// atoms
static void semanal_ident(ident_t* ident)
{
    int id;
    local_variable_t* local;
    global_variable_t* global;
    if ((local = find_local(ident, &id)))
    {
        ident->type = local->ident.type;
        ident->global = 0;
        ident->local_id = id;
    }
    else if ((global = find_global(ident, &id)))
    {
        ident->type = global->ident.type;
        ident->global = 1;
        ident->global_id = id;
    }
    else
    {
        error(ident->name->row, ident->name->col, ident->name->filename, "unkown identifier '%s'\n", ident->name->data.str);
    }
}
static void semanal_int_constant(token_t* val)
{
}
static void semanal_float_constant(token_t* val)
{
}
static void semanal_string_literal(token_t* name)
{
}

AST_PROGRAM()
{
    current_program = arg_program;
    DYNARRAY_INIT(current_program->globals, 0x100);
    AST_PROGRAM_PROCESS();
}

AST_FUNCTION()
{
    in_function = 1;
    current_function = arg_function;
    DYNARRAY_INIT(current_function->locals, 0x100);
    AST_FUNCTION_PROCESS();

    in_function = 0;
}

AST_RETURN_STATEMENT()
{
    AST_RETURN_STATEMENT_PROCESS();
}

AST_ASSIGNMENT()
{
    semanal_ident(&arg_assignment->var); // do semantic analysis on the assigned identifier
    AST_ASSIGNMENT_PROCESS();
    // TODO : try cast
    generate_type_conversion(arg_assignment->var.name, &arg_assignment->expr, arg_assignment->var.type);
}

AST_IF_STATEMENT()
{
    AST_IF_STATEMENT_PROCESS_1();
    AST_IF_STATEMENT_PROCESS_2();
    AST_IF_STATEMENT_PROCESS_3();
}

AST_WHILE_STATEMENT()
{
    AST_WHILE_STATEMENT_PROCESS_1();
    AST_WHILE_STATEMENT_PROCESS_2();
}

AST_DO_WHILE_STATEMENT()
{
    AST_DO_WHILE_STATEMENT_PROCESS_1();
    AST_DO_WHILE_STATEMENT_PROCESS_2();
}

AST_COMPOUND_STATEMENT()
{
    ++nest_depth;
    AST_COMPOUND_STATEMENT_PROCESS();
    --nest_depth;
}

AST_STATEMENT()
{
    AST_STATEMENT_PROCESS();
}

AST_TYPEDEF_DECLARATION()
{
    AST_TYPEDEF_DECLARATION_PROCESS();
}

AST_VARIABLE_DECLARATION()
{
    if (in_function)
    {
        local_variable_t local;
        local.ident.name = arg_variable_declaration->name;
        local.ident.type = arg_variable_declaration->type;
        local.nest_depth = nest_depth;
        DYNARRAY_ADD(current_function->locals, local);
    }
    else
    {
        global_variable_t global;
        global.ident.name = arg_variable_declaration->name;
        global.ident.type = arg_variable_declaration->type;
        DYNARRAY_ADD(current_program->globals, global);
    }
    AST_VARIABLE_DECLARATION_PROCESS();
}

AST_DECLARATION()
{
    AST_DECLARATION_PROCESS();
}

AST_BINOP()
{
    AST_BINOP_PROCESS_1();
    AST_BINOP_PROCESS_2();
}

AST_CAST_EXPRESSION()
{
    type_t from   = get_prim_expr_type(arg_cast_expression->expr);
    type_t to     = arg_cast_expression->target_type;
    token_t* where = arg_cast_expression->cast_type_token;
    if (!can_explicit_cast(from, to))
    {
        error(where->row, where->col, where->filename,
              "cannot cast '%s' to '%s'\n", types_str[from], types_str[to]);
    }
    AST_CAST_EXPRESSION_PROCESS();
}

AST_PRIM_EXPRESSION()
{
    AST_PRIM_EXPRESSION_PROCESS();
}

AST_EXPRESSION()
{
    AST_EXPRESSION_PROCESS();

    type_current_function = current_function;
    type_current_program = current_program;
    arg_expression->value_type = get_expression_type(arg_expression);
}
