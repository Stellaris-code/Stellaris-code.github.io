/*
parser.c

Copyright (c) 15 Yann BOUCHER (yann)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#include "parser.h"
#include "lexer.h"
#include "error.h"
#include "alloc.h"

#include <stdlib.h>
#include <string.h>
#include <assert.h>

static token_t* tokens;

static int precedence[OP_ENUM_END] =
{
    /* ADD : */ 30,
    /* SUB : */ 30,
    /* MUL : */ 40,
    /* DIV : */ 40,
    /* EQ  : */ 20,
    /* GT  : */ 10,
    /* GE  : */ 10,
    /* LT  : */ 10,
    /* LE  : */ 10,
};

static inline int token_is_type(token_t* ident)
{
    if (ident->type != TOK_IDENTIFIER)
        return 0;

    for (int i = 0; i < TYPES_END; ++i)
    {
        if (strcmp(ident->data.str, types_str[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}

static inline type_t token_type_or_fail(token_t* ident)
{
    assert(ident->type == TOK_IDENTIFIER);

    for (int i = 0; i < TYPES_END; ++i)
    {
        if (strcmp(ident->data.str, types_str[i]) == 0)
        {
            return (type_t)i;
        }
    }

    error(ident->row, ident->col, ident->filename, "Invalid type '%s'\n", ident->data.str);
}

static inline type_t token_variable_type_or_fail(token_t* ident)
{
    type_t type = token_type_or_fail(ident);

    if (type == VOID)
        error(ident->row, ident->col, ident->filename, "a variable cannot have the type 'void'\n", ident->data.str);

    return type;
}

int is_binop(int op)
{
    return op < OP_INC;
}

void set_parser_token_list(token_t *token_list)
{
    tokens = token_list;
}

token_t* next_token()
{
    return tokens;
}

token_t* consume_token()
{
    return tokens++;
}

token_t* accept(token_type_t type)
{
    token_t* cur_tok = next_token();
    if (cur_tok->type != type)
    {
        return NULL;
    }

    consume_token();

    return cur_tok;
}

token_t* expect(token_type_t type)
{
    token_t* cur_tok = next_token();
    if (cur_tok->type != type)
    {
        error(cur_tok->row, cur_tok->col, cur_tok->filename, "expected '%s', got '%s'\n", tokens_str[type], tokens_str[cur_tok->type]);
    }

    consume_token();

    return cur_tok;
}

void parse_expr(expression_t* expr, int p);

void parse_prim_expr(primary_expression_t* value)
{
    token_t* tok;
    if (accept(TOK_OPEN_PARENTHESIS))
    {
        if (token_is_type(next_token()))
        {
            token_t* tok = consume_token();

            value->type = CAST_EXPRESSION;
            value->cast_expr.target_type = token_type_or_fail(tok);
            value->cast_expr.cast_type_token = tok;
            expect(TOK_CLOSE_PARENTHESIS);

            value->cast_expr.expr = (primary_expression_t*)danpa_alloc(sizeof(primary_expression_t));
            parse_prim_expr(value->cast_expr.expr);
        }
        else
        {
            expression_t expr;
            parse_expr(&expr, 0);
            expect(TOK_CLOSE_PARENTHESIS);

            value->type = ENCLOSED;
            expression_t* factor_expr = (expression_t*)danpa_alloc(sizeof(expression_t));
            *factor_expr = expr;
            value->expr = factor_expr;
        }
    }
    else if (next_token()->type == TOK_OPERATOR &&
             (next_token()->data.op == '+' || next_token()->data.op == '-'))
    {
        token_t* op = consume_token();

        primary_expression_t* unary_op_factor = (primary_expression_t*)danpa_alloc(sizeof(primary_expression_t));
        parse_prim_expr(unary_op_factor);

        value->type = UNARY_OP_FACTOR;
        value->unary_op = op;
        value->unary_value = unary_op_factor;
    }
    else if ((tok = accept(TOK_IDENTIFIER)))
    {
        value->type = IDENT;
        value->ident.name = tok;
    }
    else if ((tok = accept(TOK_INTEGER_LITERAL)))
    {
        value->type = INT_CONSTANT;
        value->int_constant = tok;
    }
    else if ((tok = accept(TOK_FLOAT_LITERAL)))
    {
        value->type = FLOAT_CONSTANT;
        value->flt_constant = tok;
    }
    else if ((tok = accept(TOK_STRING_LITERAL)))
    {
        value->type = STRING_LITERAL;
        value->string_lit = tok;
    }
    else
    {
        tok = next_token();
        error(tok->row, tok->col, tok->filename, "expected expression got '%s'\n", tokens_str[tok->type]);
    }
}

void parse_return_statement(return_statement_t* ret_statement)
{
    expression_t expr;

    expect(KEYWORD_RETURN);
    parse_expr(&expr, 0);

    ret_statement->expr = expr;

    expect(TOK_SEMICOLON);
}

void parse_statement(statement_t* statement);

void parse_if_statement(if_statement_t* if_statement)
{
    if_statement->statement = (statement_t*)danpa_alloc(sizeof(statement_t));

    expect(KEYWORD_IF);
    expect(TOK_OPEN_PARENTHESIS);
    parse_expr(&if_statement->test, 0);
    expect(TOK_CLOSE_PARENTHESIS);
    parse_statement(if_statement->statement);

    if (accept(KEYWORD_ELSE))
    {
        statement_t* stat = (statement_t*)(danpa_alloc(sizeof(statement_t)));

        parse_statement(stat);

        if_statement->else_statement = stat;
    }
    else
    {
        if_statement->else_statement = NULL;
    }
}

void parse_while_statement(while_statement_t* while_statement)
{
    while_statement->statement = (statement_t*)danpa_alloc(sizeof(statement_t));

    expect(KEYWORD_WHILE);
    expect(TOK_OPEN_PARENTHESIS);
    parse_expr(&while_statement->test, 0);
    expect(TOK_CLOSE_PARENTHESIS);
    parse_statement(while_statement->statement);
}

void parse_do_while_statement(do_while_statement_t* while_statement)
{
    while_statement->statement = (statement_t*)danpa_alloc(sizeof(statement_t));

    expect(KEYWORD_DO);
    parse_statement(while_statement->statement);

    expect(KEYWORD_WHILE);
    expect(TOK_OPEN_PARENTHESIS);
    parse_expr(&while_statement->test, 0);
    expect(TOK_CLOSE_PARENTHESIS);
    expect(TOK_SEMICOLON);
}

void parse_assignment(assignment_t* assignment)
{
    expression_t expr;
    token_t* ident = expect(TOK_IDENTIFIER);
    expect(TOK_ASSIGNMENT_OP);
    parse_expr(&expr, 0);

    assignment->var.name = ident;
    assignment->expr = expr;

    expect(TOK_SEMICOLON);
}

void parse_typedef_declaration(typedef_declaration_t* decl)
{
    expect(KEYWORD_TYPEDEF);
    decl->type = token_type_or_fail(consume_token());
    decl->name = expect(TOK_IDENTIFIER);

    expect(TOK_SEMICOLON);
}

void parse_variable_declaration(variable_declaration_t* decl)
{
    decl->type = token_variable_type_or_fail(consume_token());
    decl->name = expect(TOK_IDENTIFIER);
    if (accept(TOK_ASSIGNMENT_OP))
    {
        assignment_t* assigment = (assignment_t*)danpa_alloc(sizeof(assignment_t));
        parse_expr(&assigment->expr, 0);
        assigment->var.name = decl->name;

        decl->init_assignment = assigment;
    }
    else
    {
        decl->init_assignment = NULL;
    }
    expect(TOK_SEMICOLON);
}

void parse_declaration(declaration_t* decl)
{
    if (token_is_type(next_token()))
    {
        decl->type = VARIABLE_DECLARATION;
        parse_variable_declaration(&decl->var);
    }
    else if (next_token()->type == KEYWORD_TYPEDEF)
    {
        decl->type = TYPEDEF_DECLARATION;
        parse_typedef_declaration(&decl->typedef_decl);
    }
}

void parse_statement(statement_t* statement)
{
    if (token_is_type(next_token()) || next_token()->type == KEYWORD_TYPEDEF)
    {
        declaration_t decl;
        parse_declaration(&decl);
        statement->type = DECLARATION;
        statement->declaration = decl;
    }
    else if (next_token()->type == KEYWORD_RETURN)
    {
        return_statement_t ret;
        parse_return_statement(&ret);
        statement->type = RETURN_STATEMENT;
        statement->return_statement = ret;
    }
    else if (next_token()->type == KEYWORD_IF)
    {
        if_statement_t if_statement;
        parse_if_statement(&if_statement);
        statement->type = IF_STATEMENT;
        statement->if_statement = if_statement;
    }
    else if (next_token()->type == KEYWORD_WHILE)
    {
        while_statement_t while_statement;
        parse_while_statement(&while_statement);
        statement->type = WHILE_STATEMENT;
        statement->while_statement = while_statement;
    }
    else if (next_token()->type == KEYWORD_DO)
    {
        do_while_statement_t while_statement;
        parse_do_while_statement(&while_statement);
        statement->type = DO_WHILE_STATEMENT;
        statement->do_while_statement = while_statement;
    }
    else if (next_token()->type == TOK_OPEN_BRACE)
    {
        consume_token();

        DYNARRAY_INIT(statement->compound.statement_list, 8);

        while (!accept(TOK_CLOSE_BRACE))
        {
            statement_t st;
            parse_statement(&st);
            DYNARRAY_ADD(statement->compound.statement_list, st);
        }

        statement->type = COMPOUND_STATEMENT;
    }
    else
    {
        assignment_t assignment;
        parse_assignment(&assignment);
        statement->type = ASSIGNMENT;
        statement->assignment = assignment;
    }
}

void parse_function(function_t* func)
{
    DYNARRAY_INIT(func->statement_list, 256);

    token_t* type = expect(TOK_IDENTIFIER);
    token_t* name = expect(TOK_IDENTIFIER);
    expect(TOK_OPEN_PARENTHESIS);
    expect(TOK_CLOSE_PARENTHESIS);
    expect(TOK_OPEN_BRACE);

    func->type = token_type_or_fail(type);
    func->name = name;

    while (next_token()->type != TOK_CLOSE_BRACE)
    {
        statement_t statement;
        parse_statement(&statement);
        DYNARRAY_ADD(func->statement_list, statement);
    }

    expect(TOK_CLOSE_BRACE);
}

void parse_program(program_t* program)
{
    DYNARRAY_INIT(program->function_list, 32);

    while (next_token()->type != TOKEN_EOF)
    {
        function_t func;
        parse_function(&func);
        DYNARRAY_ADD(program->function_list, func);
    }
}

void parse_expr(expression_t* expr, int p)
{
    expression_t* lhs = (expression_t*)danpa_alloc(sizeof(expression_t));

    primary_expression_t val;
    parse_prim_expr(&val);
    lhs->kind = PRIM_EXPR;
    lhs->prim_expr = val;

    token_t* op = next_token();
    while (op->type == TOK_OPERATOR && is_binop(op->data.op)
           && precedence[op->data.op] >= p)
    {
        consume_token();

        expression_t rhs;
        parse_expr(&rhs, precedence[op->data.op] + 1);

        expression_t* new_node = (expression_t*)danpa_alloc(sizeof(expression_t));

        new_node->kind = BINOP;
        new_node->binop = (binop_t*)danpa_alloc(sizeof(binop_t));
        new_node->binop->left = *lhs;
        new_node->binop->right = rhs;
        new_node->binop->op = op;

        lhs = new_node;

        op = next_token();
    }

    *expr = *lhs;
}
