/*
types.c

Copyright (c) 25 Yann BOUCHER (yann)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#include "types.h"
#include "error.h"
#include "ast_nodes.h"

#include <assert.h>
#include <stdint.h>

const char* types_str[TYPES_END] =
{
    "int",
    "real",
    "str",
    "void"
};

// 0 - cannot, 1 - explicit, 2 - always
const uint8_t cast_matrix[TYPES_END][TYPES_END] =
{
    // int to
    {2, 2, 0, 0},
    // real to
    {1, 2, 0, 0},
    // str to
    {0, 0, 2, 0},
    // void to
    {0, 0, 0, 0}
};

function_t* type_current_function;
program_t*  type_current_program ;

type_t get_expression_type(const expression_t *expr);

type_t get_binop_type(const binop_t* binop)
{
    type_t l_type = get_expression_type(&binop->left);
    type_t r_type = get_expression_type(&binop->right);

    if (l_type != r_type)
        error(binop->op->row, binop->op->col, binop->op->filename, "incompatible types '%s' and '%s'\n",
              types_str[l_type], types_str[r_type]);

    return l_type;
}

type_t get_prim_expr_type(const primary_expression_t* prim_expr)
{
    switch (prim_expr->type)
    {
        case ENCLOSED:
            return get_expression_type(prim_expr->expr);
        case UNARY_OP_FACTOR:
            return get_prim_expr_type(prim_expr->unary_value);
        case CAST_EXPRESSION:
            return prim_expr->cast_expr.target_type;
        case IDENT:
            return prim_expr->ident.type;
        case INT_CONSTANT:
            return INT;
        case FLOAT_CONSTANT:
            return REAL;
        case STRING_LITERAL:
            return STR;
        default:
            assert(0 && "invalid prim expr type");
    }
}

type_t get_expression_type(const expression_t *expr)
{
    if (expr->kind == PRIM_EXPR)
        return get_prim_expr_type(&expr->prim_expr);
    else if (expr->kind == BINOP)
        return get_binop_type(expr->binop);
    else
        assert(0 && "invalid expr type");
}

int can_implicit_cast(type_t from, type_t to)
{
    if (from == to)
        return 1; // trivial

    if (from >= TYPES_END || to >= TYPES_END) // user types
        return 0;

    return cast_matrix[from][to] >= 2;
}

int can_explicit_cast(type_t from, type_t to)
{
    if (from == to)
        return 1; // trivial

    if (from >= TYPES_END || to >= TYPES_END) // user types
        return 0;

    return cast_matrix[from][to] >= 1;
}
