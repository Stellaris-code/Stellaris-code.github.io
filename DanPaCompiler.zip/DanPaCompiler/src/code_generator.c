/*
code_generator.c

Copyright (c) 24 Yann BOUCHER (yann)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#include "code_generator.h"
#include "lexer.h"
#include "error.h"

#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <stdint.h>

#define AST_PASS_NAME generate
#include "ast_functions.h"

#define LABEL_MAX_LEN 16

static int label_counter;
static inline void generate_label(char* buf)
{
    snprintf(buf, LABEL_MAX_LEN, "L%x", label_counter++);
}
// atoms
static void generate_ident(ident_t* ident)
{
    if (ident->global)
        printf("pushg %d // %s\n", ident->global_id, ident->name->data.str);
    else
        printf("pushl %d // %s\n", ident->local_id, ident->name->data.str);
}
static void generate_int_constant(token_t* val)
{
    printf("pushi #%d\n", val->data.integer);
}
static void generate_float_constant(token_t* val)
{
    printf("pushf #%f\n", val->data.fp);
}
static void generate_string_literal(token_t* val)
{
    printf("pushs %s\n", val->data.str);
}

AST_PROGRAM()
{
    AST_PROGRAM_PROCESS();
}

AST_FUNCTION()
{
    AST_FUNCTION_PROCESS();
}

AST_RETURN_STATEMENT()
{
    AST_RETURN_STATEMENT_PROCESS();
    printf("ret\n");
}

AST_ASSIGNMENT()
{
    AST_ASSIGNMENT_PROCESS();
    if (arg_assignment->var.global)
        printf("movg %d // %s = *sp\n", arg_assignment->var.global_id, arg_assignment->var.name->data.str);
    else
        printf("movl %d // %s = *sp\n", arg_assignment->var.local_id,  arg_assignment->var.name->data.str);
}

AST_IF_STATEMENT()
{
    char else_label[LABEL_MAX_LEN];
    char out_label [LABEL_MAX_LEN];
    generate_label(else_label);
    generate_label(out_label );

    AST_IF_STATEMENT_PROCESS_1();
    printf("test\n");
    printf("jf .%s\n", else_label);

    AST_IF_STATEMENT_PROCESS_2();
    printf("jmp .%s\n", out_label);

    printf(".%s:\n", else_label);
    AST_IF_STATEMENT_PROCESS_3();

    printf(".%s:\n", out_label);
}

AST_WHILE_STATEMENT()
{
    char early_out_label[LABEL_MAX_LEN];
    char loop_label[LABEL_MAX_LEN];
    generate_label(early_out_label);
    generate_label(loop_label);

    printf(".%s:\n", loop_label);

    AST_WHILE_STATEMENT_PROCESS_1();
    printf("test\n");
    printf("jf .%s\n", early_out_label);

    AST_WHILE_STATEMENT_PROCESS_2();
    printf("jmp .%s\n", loop_label);

    printf(".%s:\n", early_out_label);
}

AST_DO_WHILE_STATEMENT()
{
    char loop_label[LABEL_MAX_LEN];
    generate_label(loop_label);

    printf(".%s:\n", loop_label);

    AST_DO_WHILE_STATEMENT_PROCESS_1();
    AST_DO_WHILE_STATEMENT_PROCESS_2();
    printf("test\n");

    printf("jf .%s\n", loop_label);
}

AST_COMPOUND_STATEMENT()
{
    AST_COMPOUND_STATEMENT_PROCESS();
}

AST_STATEMENT()
{
    AST_STATEMENT_PROCESS();
}

AST_TYPEDEF_DECLARATION()
{
    AST_TYPEDEF_DECLARATION_PROCESS();
}

AST_VARIABLE_DECLARATION()
{
    AST_VARIABLE_DECLARATION_PROCESS();
}

AST_DECLARATION()
{
    AST_DECLARATION_PROCESS();
}

AST_BINOP()
{
    AST_BINOP_PROCESS_1();
    AST_BINOP_PROCESS_2();

    printf("op '%s'\n", operators_str[arg_binop->op->data.op]);
}

AST_CAST_EXPRESSION()
{
    AST_CAST_EXPRESSION_PROCESS();
    printf("cast <%s>\n", types_str[arg_cast_expression->target_type]);
}

AST_PRIM_EXPRESSION()
{
    AST_PRIM_EXPRESSION_PROCESS();
}

AST_EXPRESSION()
{
    AST_EXPRESSION_PROCESS();
}
