#include <stdio.h>
#include <stdlib.h>

#include "parser.h"
#include "instructions.h"

const char* program =
"collatz:\n"
"movl 0 // get 'n'\n"
"pushl 0 // n\n"
"pushi #2\n"
"mod\n"
"pushi #0\n"
"eq\n"
"test\n"
"jf .L0\n"
"pushl 0 // n\n"
"pushi #2\n"
"idiv\n"
"ret\n"
"jmp .L1\n"
".L0:\n"
"pushi #3\n"
"pushl 0 // n\n"
"mul\n"
"pushi #1\n"
"add\n"
"ret\n"
".L1:\n"
"ret\n"
"main:\n"
"syscall #1\n"
"movl 0 // val = *sp\n"
".L2:\n"
"pushl 0 // val\n"
"call collatz\n"
"movl 0\n"
"pushl 0\n"
"syscall #0\n"
"pushl 0\n"
"pushi #1\n"
"neq\n"
"test\n"
"jt .L2\n"
"syscall #3 // exit\n"
"ret";

int main()
{
    const char* filename = "asm.dpa";
    const char* out_name = "F:/Docs Yann/DanPaVM/in.bin";

    FILE *input = fopen(filename, "r");
    fseek(input, 0, SEEK_END);
    long fsize = ftell(input);
    rewind(input);  /* same as rewind(f); */

    if (fsize <= 0)
    {
        fprintf(stderr, "could not read input file '%s'", filename);
        return -1;
    }

    uint8_t* source_buffer = malloc(fsize + 1);
    fread(source_buffer, 1, fsize, input);
    source_buffer[fsize] = '\0';
    fclose(input);

    register_instructions();

    asm_unit_t unit;
    unit.source = source_buffer;
    parse_file(&unit);

    // write output file
    FILE* file = fopen(out_name, "wb");

    // write the signature
    fwrite("DNPX", 1, 4, file);
    hash_value_t* main_addr_node = hash_table_get(&unit.labels, "main");
    uint32_t addr = 0;
    if (!main_addr_node)
        printf("warning : no 'main' symbol !\n");
    else
        addr = main_addr_node->idx;

    // write main symbol location :
    fwrite(&addr, sizeof(uint32_t), 1, file);

    fwrite(unit.object_buffer.ptr, 1, unit.object_buffer.size, file);

    fclose(file);
    return 0;
}
