#include "instructions.h"

#include <stdlib.h>
#include <errno.h>

#include "asm_unit_info.h"

static inline int32_t parse_imm_int(const char* str)
{
    if (*str != '#')
        abort();
    ++str;

    char* endptr;
    errno = 0;
    int result = strtol(str, &endptr, 0);
    if (endptr == str)
        abort();
    if (errno != 0)
        abort();

    return result;
}

static inline float parse_imm_float(const char* str)
{
    if (*str != '#')
        abort();
    ++str;

    char* endptr;
    errno = 0;
    float result = strtof(str, &endptr);
    if (endptr == str)
        abort();
    if (errno != 0)
        abort();

    return result;
}

static inline uint16_t parse_var(const char* str)
{
    char* endptr;
    errno = 0;
    int var = strtol(str, &endptr, 10);
    if (endptr == str)
        abort();
    if (errno != 0)
        abort();
    if (var < 0 || var >= 65536)
        abort();

    return var;
}

#define DECLARE_0OP(name, opbyte) \
void ins_##name(const char* operand, void* asm_unit_voidp) \
{ \
    asm_unit_t* asm_unit = asm_unit_voidp; \
    DYNARRAY_ADD(asm_unit->object_buffer, opbyte); \
}

#define DECLARE_1OP_I_IMM(name, opbyte) \
void ins_##name(const char* operand, void* asm_unit_voidp) \
{ \
    asm_unit_t* asm_unit = asm_unit_voidp; \
    DYNARRAY_ADD(asm_unit->object_buffer, opbyte); \
    DYNARRAY_RESIZE(asm_unit->object_buffer, asm_unit->object_buffer.size + 4); \
    *(uint32_t*)(asm_unit->object_buffer.ptr + asm_unit->object_buffer.size-4) = parse_imm_int(operand); \
}
#define DECLARE_1OP_F_IMM(name, opbyte) \
void ins_##name(const char* operand, void* asm_unit_voidp) \
{ \
    asm_unit_t* asm_unit = asm_unit_voidp; \
    DYNARRAY_ADD(asm_unit->object_buffer, opbyte); \
    DYNARRAY_RESIZE(asm_unit->object_buffer, asm_unit->object_buffer.size + 4); \
    *(uint32_t*)(asm_unit->object_buffer.ptr + asm_unit->object_buffer.size-4) = parse_imm_float(operand); \
}

#define DECLARE_1OP_VAR(name, opbyte) \
void ins_##name(const char* operand, void* asm_unit_voidp) \
{ \
    asm_unit_t* asm_unit = asm_unit_voidp; \
    DYNARRAY_ADD(asm_unit->object_buffer, opbyte); \
    DYNARRAY_RESIZE(asm_unit->object_buffer, asm_unit->object_buffer.size + 2); \
    *(uint16_t*)(asm_unit->object_buffer.ptr + asm_unit->object_buffer.size-2) = parse_var(operand); \
}

#define DECLARE_1OP_LBL(name, opbyte) \
void ins_##name(const char* label, void* asm_unit_voidp) \
{ \
    asm_unit_t* asm_unit = asm_unit_voidp; \
    DYNARRAY_ADD(asm_unit->object_buffer, opbyte); \
    DYNARRAY_ADD(asm_unit->relocs, (reloc_pair_t){asm_unit->object_buffer.size, label}); \
    DYNARRAY_RESIZE(asm_unit->object_buffer, asm_unit->object_buffer.size + 4); \
    *(uint32_t*)(asm_unit->object_buffer.ptr + asm_unit->object_buffer.size-4) = 0xdeadbeef; \
}

DECLARE_0OP(pop,  0x10)
DECLARE_0OP(nop, 0x90)
DECLARE_0OP(add, 0xA0)
DECLARE_0OP(sub, 0xA1)
DECLARE_0OP(mul, 0xA2)
DECLARE_0OP(idiv, 0xA3)
DECLARE_0OP(mod, 0xA4)
DECLARE_0OP(ret, 0xB0)
DECLARE_0OP(cvtf2i,0xC0)
DECLARE_0OP(cvti2f,0xC1)
DECLARE_0OP(cvti2s,0xC2)
DECLARE_0OP(cvtf2s,0xC3)
DECLARE_0OP(test,  0xE0)
DECLARE_0OP(eq,  0xE1)
DECLARE_0OP(neq, 0xE2)

DECLARE_1OP_I_IMM(pushi,   0x11)
DECLARE_1OP_F_IMM(pushf,   0x12)
DECLARE_1OP_I_IMM(syscall, 0xF0)

DECLARE_1OP_VAR(pushl,   0x13)
DECLARE_1OP_VAR(pushg,   0x14)
DECLARE_1OP_VAR(movl,   0x15)
DECLARE_1OP_VAR(movg,   0x16)

DECLARE_1OP_LBL(jt,  0x30)
DECLARE_1OP_LBL(jf,  0x31)
DECLARE_1OP_LBL(jmp, 0x32)
DECLARE_1OP_LBL(call, 0x33)

void register_instructions()
{
    ins_callbacks = mk_hash_table(211); // prime

#define REGISTER_INS(name) \
    hash_table_insert(&ins_callbacks, #name, (hash_value_t){.fn_ptr = ins_##name});

    REGISTER_INS(nop);
    REGISTER_INS(add);
    REGISTER_INS(sub);
    REGISTER_INS(mul);
    REGISTER_INS(idiv);
    REGISTER_INS(mod);
    REGISTER_INS(ret);
    REGISTER_INS(cvtf2i);
    REGISTER_INS(cvti2f);
    REGISTER_INS(cvti2s);
    REGISTER_INS(cvtf2s);
    REGISTER_INS(test);
    REGISTER_INS(eq);
    REGISTER_INS(neq);
    REGISTER_INS(pop);
    REGISTER_INS(pushi);
    REGISTER_INS(pushf);
    REGISTER_INS(syscall);
    REGISTER_INS(pushl);
    REGISTER_INS(pushg);
    REGISTER_INS(movl);
    REGISTER_INS(movg);
    REGISTER_INS(jt);
    REGISTER_INS(jf);
    REGISTER_INS(jmp);
    REGISTER_INS(call);
}
