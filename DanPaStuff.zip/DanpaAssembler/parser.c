#include "parser.h"

#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "hash_table.h"
#include "instructions.h"

static const char* source_ptr;
static const char* start_of_line;
static int current_line = 1;

uint8_t buffer[4096];

const char* parse_label()
{
    const char* start = source_ptr;
    while (isalnum(*source_ptr) || *source_ptr == '.' || *source_ptr == '_')
        ++source_ptr;
    if (*source_ptr == ':') // it's a label !
    {
        char* label_str = malloc(source_ptr - start + 1);
        memcpy(label_str, start, source_ptr - start);
        label_str[source_ptr - start] = '\0';

        ++source_ptr;

        return label_str;
    }
    else
    {
        // revert
        source_ptr = start;
        return NULL;
    }
}

const char* parse_opcode()
{
    const char* start = source_ptr;

    while (isalpha(*source_ptr))
        ++source_ptr;

    if (start == source_ptr) // no opcode
    {
        abort();
    }

    char* opcode_str = malloc(source_ptr - start + 1);
    memcpy(opcode_str, start, source_ptr - start);
    opcode_str[source_ptr - start] = '\0';

    return opcode_str;
}

const char* parse_operand()
{
    const char* start = source_ptr;

    while (isalnum(*source_ptr) || *source_ptr == '#' || *source_ptr == '.')
        ++source_ptr;

    if (start == source_ptr) // no opcode
    {
        return NULL;
    }

    char* operand_str = malloc(source_ptr - start + 1);
    memcpy(operand_str, start, source_ptr - start);
    operand_str[source_ptr - start] = '\0';

    return operand_str;
}

void consume_whitespace()
{
    while (isblank(*source_ptr))
    {
        ++source_ptr;
    }
}

void consume_comments()
{
    if (source_ptr[0] != '/' || source_ptr[1] != '/')
        return;

    while (*source_ptr && *source_ptr != '\n')
        ++source_ptr;
}

void parse_file(asm_unit_t* asm_unit)
{
    asm_unit->labels = mk_hash_table(1031); // prime number
    DYNARRAY_INIT(asm_unit->relocs, 256);
    DYNARRAY_INIT(asm_unit->object_buffer, 4096);

    source_ptr = start_of_line = asm_unit->source;
    current_line = 0;

    while (*source_ptr)
    {
        const char* label, *opcode, *operand;
        label = opcode = operand = NULL;
        ++current_line;
        start_of_line = source_ptr;

        consume_whitespace();
        if (*source_ptr == '\n')
        {
            ++source_ptr;
            continue;
        }

        while ((label = parse_label()))
        {
            hash_table_insert(&asm_unit->labels, label, (hash_value_t){.idx = asm_unit->object_buffer.size});

            consume_whitespace();
            if (*source_ptr == '\n')
            {
                ++source_ptr;
                continue;
            }
        }
        opcode = parse_opcode();

        consume_whitespace();

        operand = parse_operand();

        consume_whitespace();

        consume_comments();

        fprintf(stderr, "parsed %s %s\n", opcode, operand);

        hash_value_t* val = hash_table_get(&ins_callbacks, opcode);
        if (!val || !val->fn_ptr)
        {
            printf("unknown opcode %s\n", opcode);
            abort();
        }
        // callback to write the instruction bytes
        val->fn_ptr(operand, asm_unit);

        if (*source_ptr == '\0')
            break;
        if (*source_ptr != '\n') // wtf
        {
            printf("wot??\n");
            abort();
        }

        ++source_ptr;
    }

    // resolve relocations
    for (int i = 0; i < asm_unit->relocs.size; ++i)
    {
        hash_value_t* label_addr = hash_table_get(&asm_unit->labels, asm_unit->relocs.ptr[i].target_label);
        if (!label_addr)
            abort();

        *(uint32_t*)(asm_unit->object_buffer.ptr + asm_unit->relocs.ptr[i].reloc_index) = label_addr->idx;
    }

    for (int i = 0; i < asm_unit->labels.bucket_count; ++i)
    if (asm_unit->labels.buckets[i])
    {
        hash_node_t* chain = asm_unit->labels.buckets[i];
        while (chain)
        {
            printf("label '%s' (%d)\n", chain->key, chain->value.idx);
            chain = chain->next_node;
        }
    }

    for (int i = 0; i < asm_unit->object_buffer.size; ++i)
    {
        printf("%02x ", asm_unit->object_buffer.ptr[i]);
    }
}
