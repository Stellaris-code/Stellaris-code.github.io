#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "asm_unit_info.h"

void parse_file(asm_unit_t* asm_unit);

#endif // PARSER_H_INCLUDED
