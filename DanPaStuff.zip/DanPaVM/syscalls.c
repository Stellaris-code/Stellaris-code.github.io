#include "syscalls.h"

#include <stdlib.h>
#include <stdio.h>

#include "instructions.h"

static void print_int(vm_state_t* vm)
{
    int val = pop_stack(vm);
    printf("%d\n", val);
}

static void read_int(vm_state_t* vm)
{
    int val;
    printf("enter int : ");
    scanf("%d", &val);
    push_stack(vm, val);
}

static void vm_exit(vm_state_t* vm)
{
    vm->stopped = 1;
}

op_callback base_syscalls[256] =
{
    [0] = print_int,
    [1] = read_int,
    [3] = vm_exit
};

static void invalid_syscall(vm_state_t* vm)
{
    printf("bad syscall\n");
    abort();
}

void vm_syscall(vm_state_t* vm, int syscall_id)
{
    // base syscall
    if (syscall_id < 256)
    {
        op_callback fn = base_syscalls[syscall_id];
        if (!fn)
        {
            invalid_syscall(vm);
            return;
        }
        fn(vm);
    }
    else
    {
        // no extension syscalls yet
        invalid_syscall(vm);
    }
}
