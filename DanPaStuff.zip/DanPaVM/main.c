#include <stdio.h>
#include <stdlib.h>

#include "vm.h"

int main()
{
    FILE *input = fopen("in.bin", "rb");
    fseek(input, 0, SEEK_END);
    long fsize = ftell(input);
    rewind(input);  /* same as rewind(f); */

    if (fsize <= 0)
    {
        fprintf(stderr, "could not read input file");
        return -1;
    }

    char signature[4];
    fread(signature, 1, 4, input);

    if (strncmp(signature, "DNPX", 4) != 0)
    {
        printf("invalid signature\n");
        abort();
    }

    uint32_t main_addr;
    fread(&main_addr, sizeof(uint32_t), 1, input);

    uint8_t* buffer = malloc(fsize);
    fread(buffer, 1, fsize, input);
    fclose(input);

    vm_state_t* vm = calloc(1, sizeof(vm_state_t));
    vm->exec_buffer = buffer;
    vm->pc = main_addr;

    while (!vm->stopped)
        step(vm);

    free(vm);
    free(buffer);
    return 0;
}
