#ifndef INSTRUCTIONS_H_INCLUDED
#define INSTRUCTIONS_H_INCLUDED

#include <stdint.h>

#include "vm.h"

typedef void(*op_callback)(vm_state_t*);

extern op_callback instructions[256];

#endif // INSTRUCTIONS_H_INCLUDED
