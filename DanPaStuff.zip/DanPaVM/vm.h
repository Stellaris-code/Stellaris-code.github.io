#ifndef VM_H_INCLUDED
#define VM_H_INCLUDED

#include <stdint.h>

#define STACK_DEPTH 65536
#define MAX_CALL_DEPTH 16
#define VAR_COUNT 65536
#define LVAR_PAGES MAX_CALL_DEPTH

typedef struct vm_state_t
{
    uint32_t pc;
    uint32_t sp;
    uint8_t truth_flag;
    int stopped;

    uint32_t glob_vars[VAR_COUNT];
    uint32_t loc_var_pages[LVAR_PAGES][VAR_COUNT];

    uint32_t data_stack[STACK_DEPTH];
    uint32_t call_stack[MAX_CALL_DEPTH];
    int      call_depth;

    uint8_t* exec_buffer;
} vm_state_t;

void step(vm_state_t* vm);

inline uint32_t pop_stack(vm_state_t* vm)
{
    --vm->sp;
    if (vm->sp >= STACK_DEPTH) // covers the case of underflow
    {
        abort();
    }
    uint32_t val = vm->data_stack[vm->sp];

    return val;
}

inline void push_stack(vm_state_t* vm, uint32_t value)
{
    if ((vm->sp+1) >= STACK_DEPTH) // covers the case of underflow
    {
        abort();
    }
    vm->data_stack[vm->sp] = value;
    ++vm->sp;
}

#endif // VM_H_INCLUDED
