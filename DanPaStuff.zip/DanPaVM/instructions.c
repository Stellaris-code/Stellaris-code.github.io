#include "instructions.h"

#include <stdlib.h>
#include <stdio.h>

#include "syscalls.h"

static void nop(vm_state_t* vm)
{
    // litteraly do nothing.
}

static void pop(vm_state_t* vm)
{
    pop_stack(vm);
}

static void pushi(vm_state_t* vm)
{
    uint32_t val = *(uint32_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 4;

    push_stack(vm, val);
}

static void pushf(vm_state_t* vm)
{
    uint32_t val = *(uint32_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 4;

    push_stack(vm, val);
}

static void pushl(vm_state_t* vm)
{
    uint16_t var = *(uint16_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 2;

    push_stack(vm, vm->loc_var_pages[vm->call_depth][var]);
}

static void pushg(vm_state_t* vm)
{
    uint16_t var = *(uint16_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 2;

    push_stack(vm, vm->glob_vars[var]);
}

static void movl(vm_state_t* vm)
{
    uint16_t var = *(uint16_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 2;

    vm->loc_var_pages[vm->call_depth][var] = pop_stack(vm);
}

static void movg(vm_state_t* vm)
{
    uint16_t var = *(uint16_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 2;

    vm->glob_vars[var] = pop_stack(vm);
}

static void add(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 + var2;
    push_stack(vm, result);
}

static void sub(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 - var2;
    push_stack(vm, result);
}

static void mul(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 * var2;
    push_stack(vm, result);
}

static void idiv(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 / var2;
    push_stack(vm, result);
}

static void mod(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 % var2;
    push_stack(vm, result);
}

static void test(vm_state_t* vm)
{
    int32_t var = pop_stack(vm);
    vm->truth_flag = !!var;
}

static void eq(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 == var2;
    push_stack(vm, result);
}

static void neq(vm_state_t* vm)
{
    int32_t var2 = pop_stack(vm);
    int32_t var1 = pop_stack(vm);

    int32_t result = var1 != var2;
    push_stack(vm, result);
}

static void jt(vm_state_t* vm)
{
    uint32_t branch = *(uint32_t*)&vm->exec_buffer[vm->pc];
    if (vm->truth_flag)
        vm->pc = branch;
    else
        vm->pc += 4;
}

static void jf(vm_state_t* vm)
{
    uint32_t branch = *(uint32_t*)&vm->exec_buffer[vm->pc];
    if (!vm->truth_flag)
        vm->pc = branch;
    else
        vm->pc += 4;
}

static void jmp(vm_state_t* vm)
{
    uint32_t branch = *(uint32_t*)&vm->exec_buffer[vm->pc];
    vm->pc = branch;
}

static void call(vm_state_t* vm)
{
    if (vm->call_depth >= MAX_CALL_DEPTH)
        abort();

    uint32_t branch = *(uint32_t*)&vm->exec_buffer[vm->pc];
    vm->call_stack[vm->call_depth] = vm->pc + 4;
    ++vm->call_depth;

    vm->pc = branch;
}

static void ret(vm_state_t* vm)
{
    if (vm->call_depth == 0)
        abort();

    --vm->call_depth;
    vm->pc = vm->call_stack[vm->call_depth];
}

static void syscall(vm_state_t* vm)
{
    uint32_t id = *(uint32_t*)&vm->exec_buffer[vm->pc];
    vm->pc += 4;

    vm_syscall(vm, id);
}

op_callback instructions[256] =
{
    [0x90] = nop,
    [0x10] = pop,
    [0x11] = pushi,
    [0x12] = pushf,
    [0x13] = pushl,
    [0x14] = pushg,
    [0x15] = movl,
    [0x16] = movg,

    [0x30] = jt,
    [0x31] = jf,
    [0x32] = jmp,
    [0x33] = call,

    [0xA0] = add,
    [0xA1] = sub,
    [0xA2] = mul,
    [0xA3] = idiv,
    [0xA4] = mod,

    [0xB0] = ret,

    [0xE0] = test,
    [0xE1] = eq,
    [0xE2] = neq,

    [0xF0] = syscall,
};
