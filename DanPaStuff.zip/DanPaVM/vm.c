#include "vm.h"

#include <stdlib.h>

#include "instructions.h"

void step(vm_state_t* vm)
{
    uint8_t opcode = vm->exec_buffer[vm->pc];
    op_callback callback = instructions[opcode];
    ++vm->pc;

    //printf("executing opcode 0x%x\n", opcode);

    if (!callback)
        abort();

    callback(vm);
}
